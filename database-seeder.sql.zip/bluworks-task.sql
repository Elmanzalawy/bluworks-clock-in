-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2024 at 12:48 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bluworks-task`
--

-- --------------------------------------------------------

--
-- Table structure for table `clock_ins`
--

CREATE TABLE `clock_ins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `worker_id` bigint(20) UNSIGNED NOT NULL,
  `latitude` decimal(8,5) NOT NULL,
  `longitude` decimal(8,5) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clock_ins`
--

INSERT INTO `clock_ins` (`id`, `worker_id`, `latitude`, `longitude`, `timestamp`) VALUES
(1, 8, '-49.49174', '-9.70944', '1987-07-03 10:29:01'),
(2, 6, '20.05525', '140.67615', '1998-04-16 04:45:58'),
(3, 4, '-46.97483', '-97.56180', '1971-09-17 20:35:48'),
(4, 1, '63.27974', '17.36693', '2017-08-03 06:01:33'),
(5, 1, '-36.74088', '112.57258', '1988-10-27 19:56:14'),
(6, 5, '44.62146', '-147.91792', '1990-02-15 02:36:22'),
(7, 2, '60.17541', '-178.05810', '1997-09-24 18:15:40'),
(8, 10, '87.82081', '163.68407', '1998-11-16 21:28:54'),
(9, 10, '54.23639', '-128.27056', '2010-12-13 08:07:34'),
(10, 7, '-42.70918', '-163.72602', '1996-07-01 17:07:40'),
(11, 3, '63.84440', '69.43763', '1988-04-29 09:09:01'),
(12, 8, '74.75189', '48.49031', '1970-01-16 07:45:07'),
(13, 4, '-57.79774', '-61.62217', '1999-07-29 17:03:27'),
(14, 6, '87.48581', '120.51512', '1970-11-05 20:42:53'),
(15, 5, '-17.95651', '-75.17627', '2009-06-24 05:33:20'),
(16, 7, '-28.25869', '57.62223', '1979-07-23 10:59:14'),
(17, 5, '15.39324', '-8.54442', '1985-06-05 18:45:40'),
(18, 9, '72.25041', '-174.17497', '1982-04-04 03:01:21'),
(19, 5, '-20.03004', '-69.76004', '1970-11-30 22:01:53'),
(20, 10, '37.79645', '34.42174', '2021-09-11 02:24:53'),
(21, 8, '20.69579', '-176.14360', '1981-04-13 17:58:38'),
(22, 6, '86.79311', '149.11433', '1995-05-17 14:10:12'),
(23, 7, '1.87790', '110.40319', '2004-09-14 09:05:40'),
(24, 7, '89.41238', '169.44466', '1988-02-13 08:33:46'),
(25, 6, '-59.36151', '-5.53920', '1982-03-15 21:41:14'),
(26, 8, '8.12466', '79.12446', '2005-08-20 20:47:04'),
(27, 3, '-58.91203', '-134.62471', '1976-08-11 20:11:09'),
(28, 10, '30.06849', '37.61806', '2017-09-01 15:52:59'),
(29, 2, '-71.83497', '-166.28922', '1990-09-11 14:56:31'),
(30, 1, '35.45738', '-30.89571', '1986-01-03 02:07:37'),
(31, 9, '9.41543', '11.45593', '1973-11-19 08:12:44'),
(32, 1, '-14.88711', '-27.50507', '2015-12-18 10:16:52'),
(33, 2, '67.01964', '-148.84012', '1983-11-02 07:09:28'),
(34, 8, '-81.67032', '81.61011', '2009-09-30 08:42:05'),
(35, 4, '-70.80479', '102.79061', '1981-04-25 06:55:12'),
(36, 8, '-34.62626', '-125.34292', '1998-02-21 16:05:07'),
(37, 7, '82.89070', '104.23655', '1987-03-07 09:33:27'),
(38, 5, '-69.68183', '-131.81933', '1973-07-22 07:15:50'),
(39, 3, '-85.06689', '159.54794', '2010-11-22 01:59:10'),
(40, 1, '3.41903', '53.62514', '2023-02-21 20:32:10'),
(41, 8, '22.61856', '14.44854', '2018-03-15 16:40:35'),
(42, 2, '-50.94352', '-7.71798', '2021-01-23 23:02:49'),
(43, 8, '58.22260', '-92.83072', '1998-12-01 15:52:59'),
(44, 7, '55.13550', '-13.33227', '2006-05-24 15:28:40'),
(45, 4, '-4.61248', '53.30371', '2012-09-22 20:59:33'),
(46, 7, '-25.58564', '-13.05639', '2004-04-07 04:51:16'),
(47, 2, '-88.98814', '-56.99914', '2009-02-04 17:58:57'),
(48, 6, '56.60067', '-139.55536', '1998-03-11 14:52:57'),
(49, 9, '-71.25271', '-119.88687', '2006-11-09 02:15:59'),
(50, 4, '16.02996', '-114.96990', '2013-11-25 00:31:00'),
(51, 4, '-75.24975', '13.61437', '1992-03-08 03:33:56'),
(52, 6, '76.77497', '153.25504', '1982-10-15 19:38:07'),
(53, 5, '62.54422', '143.96279', '1972-10-02 06:23:12'),
(54, 9, '-84.95067', '-64.54225', '1972-06-14 17:07:24'),
(55, 10, '11.92568', '95.30643', '2021-02-02 06:25:53'),
(56, 2, '-10.88922', '-131.29407', '1985-06-25 22:45:59'),
(57, 2, '82.13445', '-101.95873', '1991-03-01 23:15:24'),
(58, 3, '-73.04935', '70.41201', '2007-09-20 01:04:18'),
(59, 3, '-77.47195', '-118.48431', '1985-11-25 17:02:40'),
(60, 2, '-73.44319', '-150.22379', '2000-04-18 12:11:01'),
(61, 8, '-48.43110', '-129.40295', '2009-05-20 06:48:46'),
(62, 9, '-39.20520', '143.05818', '2024-02-09 06:26:51'),
(63, 2, '7.11271', '14.72271', '2019-01-10 18:22:36'),
(64, 4, '4.07185', '131.12549', '2008-03-24 22:30:53'),
(65, 6, '29.02514', '-65.09113', '1974-12-25 01:24:40'),
(66, 3, '-7.53493', '142.34468', '2002-08-03 03:21:36'),
(67, 3, '-40.02102', '-99.95611', '1980-03-23 18:18:47'),
(68, 5, '-1.14782', '-106.12466', '2004-11-02 00:19:20'),
(69, 5, '54.33779', '72.19663', '1999-08-01 18:51:04'),
(70, 4, '-58.59732', '-33.53289', '1992-09-22 07:54:12'),
(71, 4, '-42.33034', '-84.20555', '2016-10-22 11:19:00'),
(72, 9, '44.64109', '-105.83479', '2010-01-11 03:52:26'),
(73, 4, '24.63242', '52.65773', '2021-03-19 21:03:38'),
(74, 8, '3.52505', '-56.58679', '1985-05-19 18:52:26'),
(75, 6, '15.12727', '-79.53053', '2021-09-14 03:38:15'),
(76, 8, '-86.93948', '-128.74457', '2023-08-08 01:52:52'),
(77, 5, '84.23366', '158.55242', '1994-12-12 00:05:39'),
(78, 3, '-45.14446', '36.43943', '1976-01-30 07:43:47'),
(79, 6, '84.88487', '15.03474', '2020-04-15 19:13:32'),
(80, 7, '-72.94926', '-12.07210', '2020-02-02 04:56:31'),
(81, 8, '31.66942', '128.76323', '2003-02-13 19:28:47'),
(82, 5, '-35.11477', '17.58540', '2014-09-15 23:24:13'),
(83, 4, '-17.33966', '-172.85371', '2023-05-08 12:02:53'),
(84, 5, '-74.73620', '154.59249', '1990-04-30 03:52:23'),
(85, 2, '84.87158', '-21.10144', '2020-06-19 01:28:09'),
(86, 3, '72.20998', '91.46288', '1994-12-09 08:40:16'),
(87, 6, '-65.49104', '105.27110', '1974-07-12 02:17:34'),
(88, 10, '-82.25738', '2.88823', '1981-03-12 21:50:22'),
(89, 8, '34.79855', '146.88846', '1983-07-18 03:48:07'),
(90, 4, '-9.16835', '-172.21400', '1970-01-20 07:38:19'),
(91, 1, '34.81724', '-95.47060', '2005-05-24 14:39:27'),
(92, 4, '-16.95773', '1.19836', '1983-10-31 15:18:24'),
(93, 8, '-16.03732', '-159.24751', '1990-03-17 10:48:55'),
(94, 5, '83.68127', '61.26741', '2004-01-03 22:11:26'),
(95, 8, '64.04076', '28.76834', '1997-09-10 00:14:37'),
(96, 6, '67.74448', '135.47945', '1991-06-09 10:51:54'),
(97, 5, '-76.74576', '62.79414', '1995-05-16 13:25:38'),
(98, 2, '26.52126', '7.60286', '1981-06-12 04:57:33'),
(99, 1, '69.80070', '86.54882', '1984-12-01 09:24:27'),
(100, 10, '-73.33365', '161.92550', '1973-08-17 09:32:20');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2024_05_15_161513_create_workers_table', 1),
(6, '2024_05_15_161912_create_clock_ins_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `workers`
--

CREATE TABLE `workers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `workers`
--

INSERT INTO `workers` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Chadd O\'Connell', '2024-05-15 19:47:56', '2024-05-15 19:47:56', NULL),
(2, 'Anjali Harber', '2024-05-15 19:47:56', '2024-05-15 19:47:56', NULL),
(3, 'Miss Katrina Gutkowski', '2024-05-15 19:47:56', '2024-05-15 19:47:56', NULL),
(4, 'Dedrick Glover III', '2024-05-15 19:47:56', '2024-05-15 19:47:56', NULL),
(5, 'Saige Hills Sr.', '2024-05-15 19:47:56', '2024-05-15 19:47:56', NULL),
(6, 'Kara Rodriguez Sr.', '2024-05-15 19:47:56', '2024-05-15 19:47:56', NULL),
(7, 'Eusebio Bosco I', '2024-05-15 19:47:56', '2024-05-15 19:47:56', NULL),
(8, 'Dr. Tierra Hettinger', '2024-05-15 19:47:56', '2024-05-15 19:47:56', NULL),
(9, 'Fae Cruickshank', '2024-05-15 19:47:56', '2024-05-15 19:47:56', NULL),
(10, 'Dr. Queen Schimmel', '2024-05-15 19:47:56', '2024-05-15 19:47:56', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clock_ins`
--
ALTER TABLE `clock_ins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `clock_ins_worker_id_foreign` (`worker_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `workers`
--
ALTER TABLE `workers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clock_ins`
--
ALTER TABLE `clock_ins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `workers`
--
ALTER TABLE `workers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `clock_ins`
--
ALTER TABLE `clock_ins`
  ADD CONSTRAINT `clock_ins_worker_id_foreign` FOREIGN KEY (`worker_id`) REFERENCES `workers` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
